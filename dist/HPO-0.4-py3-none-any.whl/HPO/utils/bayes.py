import numpy as np
def sample(population_mu,population_sigma, sample_means):
  prior = np.random.normal(loc = population_mu)
